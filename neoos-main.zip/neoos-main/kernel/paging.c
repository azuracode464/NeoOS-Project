#include "types.h"
#include "paging.h"
#include "kernel.h"

neo_bool paging_init(void) {
    // Configuração básica de paginação
    return neo_true;
}
