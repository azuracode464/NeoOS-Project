#include "types.h"
#ifndef INTERRUPT_H
#define INTERRUPT_H

neo_bool interrupt_init(void);

#endif
