#ifndef GRAPHICS_H
#define GRAPHICS_H

// Placeholder para futuras funções gráficas

#endif
