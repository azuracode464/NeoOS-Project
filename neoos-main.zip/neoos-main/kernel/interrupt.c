#include "types.h"
#include "interrupt.h"
#include "kernel.h"

neo_bool interrupt_init(void) {
    // Configuração básica da IDT
    return neo_true;
}
