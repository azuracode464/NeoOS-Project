#include "types.h"
#ifndef DRIVER_H
#define DRIVER_H

neo_bool driver_init(void);
void driver_update(void);

#endif
