#include "types.h"
#ifndef PAGING_H
#define PAGING_H

neo_bool paging_init(void);

#endif

