#include "types.h"
#ifndef SHELL_H
#define SHELL_H

neo_bool shell_init(void);

#endif
