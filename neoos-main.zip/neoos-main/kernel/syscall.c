#include "syscall.h"
#include "kernel.h"

void syscall_init(void) {
    // Configura a entrada de syscalls
}

void syscall_process(void) {
    // Processa syscalls pendentes
}
