#include "network.h"
#include "kernel.h"

void network_init(void) {
    // Inicialização básica
}

void network_shutdown(void) {
    // Shutdown básico
}

void network_process(void) {
    // Processamento de rede
}
