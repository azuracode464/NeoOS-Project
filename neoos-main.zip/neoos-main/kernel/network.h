#ifndef NETWORK_H
#define NETWORK_H

void network_init(void);
void network_shutdown(void);
void network_process(void);

#endif
