#include "types.h"
#ifndef TIMER_H
#define TIMER_H

neo_bool timer_init(neo_u32 frequency);

#endif
