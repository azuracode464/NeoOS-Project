#include "sound.h"

void sound_init(void) {
    // Inicialização básica
}

void sound_shutdown(void) {
    // Shutdown básico
}
