#include "types.h"
#include "shell.h"
#include "kernel.h"

neo_bool shell_init(void) {
    return neo_true; // Shell básico implementado no kernel
}
