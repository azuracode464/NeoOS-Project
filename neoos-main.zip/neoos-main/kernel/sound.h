#ifndef SOUND_H
#define SOUND_H

void sound_init(void);
void sound_shutdown(void);

#endif	
